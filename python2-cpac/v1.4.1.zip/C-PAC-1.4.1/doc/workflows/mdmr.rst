Multivariate Distance Matrix Regression
===================================

.. automodule:: CPAC.cwas
    :members:

