Functional Preprocessing
========================

.. automodule:: CPAC.func_preproc
    :members:
