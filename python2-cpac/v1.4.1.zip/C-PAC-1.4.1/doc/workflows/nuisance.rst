Nuisance Signal Removal
=======================

.. automodule:: CPAC.nuisance
    :members:
