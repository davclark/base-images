Scrubbing
==========

.. automodule:: CPAC.scrubbing
    :members:
