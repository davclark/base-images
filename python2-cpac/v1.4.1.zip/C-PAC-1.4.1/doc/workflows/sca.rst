Seed Based Correlation Analysis
===============================

.. automodule:: CPAC.sca
    :members:
