.. CPAC Developer documentation master file, created by
   sphinx-quickstart on Thu Jun 21 14:49:46 2012.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

For Developers 
==============

Contents:

.. toctree::
   :maxdepth: 2

   installation
   workflow_documentation
   testing

