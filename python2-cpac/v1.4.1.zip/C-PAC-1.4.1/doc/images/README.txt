All images related to documentation will be placed here.
