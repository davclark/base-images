# test/reg/__init__.py
#

'''
This subpackage contains modules for regression testing C-PAC
'''