from group_analysis import create_fsl_flame_wf, \
                           get_operation


__all__ = ['create_fsl_flame_wf', \
           'get_operation']
