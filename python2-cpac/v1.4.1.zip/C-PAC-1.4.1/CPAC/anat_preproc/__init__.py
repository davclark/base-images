# -*- coding: utf-8 -*-

from CPAC.anat_preproc.anat_preproc import create_anat_preproc
