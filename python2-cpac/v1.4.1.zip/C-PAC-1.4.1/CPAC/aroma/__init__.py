from CPAC.aroma.aroma import create_aroma
