##Here data is hardcoded need to change that
##update resource pool information
