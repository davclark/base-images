# -*- coding: utf-8 -*-

from CPAC.alff.alff import create_alff
